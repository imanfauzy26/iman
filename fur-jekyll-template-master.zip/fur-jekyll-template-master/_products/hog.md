---
name: Todd the Hedgehog
description_markdown: >-
  Todd the hedgehog may have a spiky exterior but his heart is made of gold.
  Unfortunately this weighs him down and makes it difficult for him to get
  around.



  Slim Fit, 5oz 100% Cotton T-Shirt.
garment_type:
price: '9.00'
sku: hog
stock: 10
sizes:
  - Small
  - Medium
  - Large
  - XL
styles:
  - name: Clay
    color: '#9c5145'
    image: /images/products/hog/clay.jpg
  - name: Cream
    color: '#dfd3c2'
    image: /images/products/hog/cream.jpg
  - name: Blue
    color: '#39589e'
    image: /images/products/hog/blue.jpg
---
