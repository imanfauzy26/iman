---
name: Sacha the Deer
description_markdown: >-
  Sacha's elegant antlers have never been seen on such a beautiful t-shirt. Wear
  this majestic beast and feel all your problems float away.



  Slim Fit, 5oz 100% Cotton T-Shirt.
garment_type:
price: '9.00'
sku: deer
stock: 10
sizes:
  - Small
  - Medium
  - Large
  - XL
styles:
  - name: Black
    color: '#000000'
    image: /images/products/deer/black.jpg
  - name: Blue
    color: '#39589e'
    image: /images/products/deer/blue.jpg
  - name: Clay
    color: '#9c5145'
    image: /images/products/deer/clay.jpg
  - name: Cream
    color: '#dfd3c2'
    image: /images/products/deer/cream.jpg
---