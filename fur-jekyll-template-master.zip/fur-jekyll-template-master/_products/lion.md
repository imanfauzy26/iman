---
name: Scar the Lion
description_markdown: >-
  Scar the lion is always true to himself. The Mufasa tragedy was a slight
  blemish in what was otherwise a saint-like life.



  Slim Fit, 5oz 100% Cotton T-Shirt.
garment_type:
price: '9.00'
sku: lion
stock: 10
sizes:
  - Small
  - Medium
  - Large
  - XL
styles:
  - name: Blue
    color: '#39589e'
    image: /images/products/lion/blue.jpg
---
