---
name: Gavin the Tiger
description_markdown: >-
  Gavin the tiger was brought up vegan. His favorite meal is chickpea salad with
  a lemon juice dressing.



  Slim Fit, 5oz 100% Cotton T-Shirt.
garment_type:
price: '9.00'
sku: tiger
stock: 10
sizes:
  - Small
  - Medium
  - Large
  - XL
styles:
  - name: Black
    color: '#000000'
    image: /images/products/tiger/black.jpg
  - name: Blue
    color: '#39589e'
    image: /images/products/tiger/blue.jpg
  - name: Clay
    color: '#9c5145'
    image: /images/products/tiger/clay.jpg
  - name: Cream
    color: '#dfd3c2'
    image: /images/products/tiger/cream.jpg
  - name: Green
    color: '#67aa79'
    image: /images/products/tiger/green.jpg
---