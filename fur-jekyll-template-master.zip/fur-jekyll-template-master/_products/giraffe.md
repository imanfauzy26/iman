---
name: Gerald the Giraffe
description_markdown: >-
  Gerald the giraffe isn't particularly spiritual but he has a long neck which
  can help you in a pinch.



  Slim Fit, 5oz 100% Cotton T-Shirt.
garment_type:
price: '9.00'
sku: giraffe
stock: 10
sizes:
  - Small
  - Medium
  - Large
  - XL
styles:
  - name: Green
    color: '#67aa79'
    image: /images/products/giraffe/green.jpg
---