---
name: Bumble the Elephant
description_markdown: >-
  Bumble the humble elephant is your shining star. He will always remember who
  you are and why you are here.



  Slim Fit, 5oz 100% Cotton T-Shirt.
garment_type:
price: '9.00'
sku: elephant
stock: 10
sizes:
  - Small
  - Medium
  - Large
  - XL
styles:
  - name: Cream
    color: '#dfd3c2'
    image: /images/products/elephant/cream.jpg
  - name: Green
    color: '#67aa79'
    image: /images/products/elephant/green.jpg
---