---
name:
garment_type: top
price:
sku:
description:
sizes:
  - XS
  - Small
  - Medium
  - Large
  - XL
styles:
  - name:
    color:
    image:
---
